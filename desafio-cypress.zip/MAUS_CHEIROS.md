# Relatório de Identificação de Maus Cheiros e Refatorações

Este documento detalha os 7 maus cheiros (*code smells*) identificados no arquivo `app-dirty.js` original e as respectivas estratégias de refatoração aplicadas com base em Clean Code e Martin Fowler.

### 1. Variáveis Globais Expostas (Global Data)
* **Onde existia:** Variáveis `var a`, `var c` e `var flt` declaradas soltas no escopo global.
* **Refatoração:** Mudança para uma arquitetura orientada a objetos usando a classe `TodoApp`. O estado (`tasks`, `currentFilter`) agora é uma propriedade encapsulada privada da instância.

### 2. Nomes Pobres / Não Intuitivos (Mysterious Name)
* **Onde existia:** Funções com nomes como `doIt(mode)`, variáveis de dados curtas como `a` (array), `c` (contador), `flt` (filtro), e propriedades do objeto como `txt` e `ok`.
* **Refatoração:** Substituição por nomes significativos e descritivos: `addTask`, `toggleTask`, `deleteTask`, `currentFilter`, e propriedades claras como `text` e `isCompleted`.

### 3. Função Longa com Responsabilidades Excessivas (Long Method / Single Responsibility Violation)
* **Onde existia:** A função `doIt` realizava captura do DOM, escuta de eventos, lógica de negócios, validação de campos vazios e renderização visual em um único bloco.
* **Refatoração:** Separação das responsabilidades em métodos curtos e especializados: `cacheDOM()`, `bindEvents()`, `addTask()`, `render()`.

### 4. Strings e Valores Mágicos (Magic Values)
* **Onde existia:** Uso de strings literais e números mágicos como `mode === 1`, `mode === 2`, `flt === "1"`, `flt === "2"`.
* **Refatoração:** Substituição dos modos por métodos nomeados explicitamente e mapeamento descritivo dos estados de filtro para `"all"`, `"pending" e `"completed"`.

### 5. Código Duplicado (Duplicated Code)
* **Onde existia:** O bloco completo que gerava os elementos na tela (`l.innerHTML = ""...` e os loops `for`) estava copiado integralmente dentro da condicional `mode === 1` e no bloco `else`.
* **Refatoração:** Extração da lógica de construção da tela para um método único centralizado chamado `render()`, invocado sempre que o estado sofre mutação.

### 6. Parâmetro de Flag / Controle (Flag Argument)
* **Onde existia:** O argumento `mode` na função `doIt(mode)` funcionava como uma flag que dividia arbitrariamente o fluxo de execução interna da função.
* **Refatoração:** Eliminação do parâmetro de controle. O fluxo agora é direcionado através de interações diretas e chamadas limpas de métodos de evento.

### 7. Código Morto / Comentado (Dead Code)
* **Onde existia:** As linhas contendo `var notUsed = 123;` e `if(false){...}` estavam comentadas no topo da função, sujando a leitura do arquivo.
* **Refatoração:** Remoção completa do código inútil, garantindo que o arquivo final contenha apenas código em produção ativa.