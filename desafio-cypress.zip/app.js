class TodoApp {
  constructor() {
    this.tasks = [];
    this.currentFilter = "all";
    this.domElements = {};
  }

  init() {
    this.cacheDOM();
    this.bindEvents();
    this.render();
  }

  cacheDOM() {
    this.domElements = {
      input: document.getElementById("todo-input"),
      addButton: document.getElementById("add-button"),
      list: document.getElementById("todo-list"),
      filterButtons: document.querySelectorAll(".filter-btn")
    };
  }

  bindEvents() {
    this.domElements.addButton.addEventListener("click", () => this.handleAddTask());
    
    this.domElements.filterButtons.forEach(button => {
      button.addEventListener("click", (e) => {
        this.currentFilter = e.target.getAttribute("data-filter");
        this.render();
      });
    });
  }

  // Métodos de Regra de Negócio (Facilitam Testes Unitários)
  addTask(text) {
    const sanitizedText = text ? text.trim() : "";
    if (!sanitizedText) {
      alert("Digite algo");
      return null;
    }

    const newTask = {
      id: Date.now(), // Evita contador mágico global
      text: sanitizedText,
      isCompleted: false
    };

    this.tasks.push(newTask);
    return newTask;
  }

  toggleTask(id) {
    const task = this.tasks.find(t => t.id === Number(id));
    if (task) {
      task.isCompleted = !task.isCompleted;
    }
    return task;
  }

  deleteTask(id) {
    this.tasks = this.tasks.filter(t => t.id !== Number(id));
  }

  getFilteredTasks() {
    if (this.currentFilter === "pending") {
      return this.tasks.filter(t => !t.isCompleted);
    }
    if (this.currentFilter === "completed") {
      return this.tasks.filter(t => t.isCompleted);
    }
    return this.tasks;
  }

  // Métodos de Renderização de Interface (Interface/DOM)
  handleAddTask() {
    const text = this.domElements.input.value;
    if (this.addTask(text)) {
      this.domElements.input.value = "";
      this.render();
    }
  }

  render() {
    this.domElements.list.innerHTML = "";
    const filtered = this.getFilteredTasks();

    filtered.forEach(task => {
      const li = document.createElement("li");
      if (task.isCompleted) {
        li.className = "done";
      }

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = task.isCompleted;
      checkbox.addEventListener("change", () => {
        this.toggleTask(task.id);
        this.render();
      });

      const span = document.createElement("span");
      span.textContent = task.text;

      const deleteBtn = document.createElement("button");
      deleteBtn.textContent = "x";
      deleteBtn.className = "delete-btn";
      deleteBtn.addEventListener("click", () => {
        this.deleteTask(task.id);
        this.render();
      });

      li.appendChild(checkbox);
      li.appendChild(span);
      li.appendChild(deleteBtn);
      this.domElements.list.appendChild(li);
    });
  }
}

// Inicializa a aplicação no navegador
document.addEventListener("DOMContentLoaded", () => {
  window.todoAppInstance = new TodoApp();
  window.todoAppInstance.init();
});

// Exporta para os testes unitários em ambiente Node/Cypress se necessário
if (typeof module !== "undefined" && module.exports) {
  module.exports = TodoApp;
}