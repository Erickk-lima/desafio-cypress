describe('Testes Funcionais (E2E) - Lista de Tarefas', () => {
  beforeEach(() => {
    // Abre a aplicação (garanta que o caminho ou servidor local coincida)
    cy.visit('index.html'); 
  });

  it('Deve adicionar uma nova tarefa com sucesso', () => {
    cy.get('#todo-input').type('Minha tarefa funcional');
    cy.get('#add-button').click();
    
    cy.get('#todo-list li').should('have.length', 1);
    cy.get('#todo-list li').span().should('contain', 'Minha tarefa funcional');
  });

  it('Deve alternar a conclusão de uma tarefa', () => {
    cy.get('#todo-input').type('Tarefa para concluir');
    cy.get('#add-button').click();

    cy.get('#todo-list li input[type="checkbox"]').check();
    cy.get('#todo-list li').should('have.class', 'done');
  });

  it('Deve excluir uma tarefa da lista', () => {
    cy.get('#todo-input').type('Tarefa para deletar');
    cy.get('#add-button').click();

    cy.get('#todo-list li .delete-btn').click();
    cy.get('#todo-list li').should('have.length', 0);
  });

  it('Deve filtrar as tarefas corretamente entre pendentes e concluídas', () => {
    // Adiciona duas tarefas
    cy.get('#todo-input').type('Tarefa A Fazer');
    cy.get('#add-button').click();
    cy.get('#todo-input').type('Tarefa Concluída');
    cy.get('#add-button').click();

    // Conclui a segunda tarefa
    cy.get('#todo-list li').eq(1).find('input[type="checkbox"]').check();

    // Filtra por "A Fazer"
    cy.get('#filter-pending').click();
    cy.get('#todo-list li').should('have.length', 1);
    cy.get('#todo-list li').should('not.have.class', 'done');

    // Filtra por "Concluídos"
    cy.get('#filter-completed').click();
    cy.get('#todo-list li').should('have.length', 1);
    cy.get('#todo-list li').should('have.class', 'done');
  });
});