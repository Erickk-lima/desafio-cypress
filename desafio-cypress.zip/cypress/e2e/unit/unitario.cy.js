describe('Testes Unitários - Classe TodoApp (Regra de Negócio)', () => {
  let app;

  beforeEach(() => {
    cy.visit('index.html').then((win) => {
      // Captura a instância viva da classe criada na janela global do navegador
      app = win.todoAppInstance;
    });
  });

  it('Regra: Não deve permitir adicionar tarefas vazias ou com espaços', () => {
    const resultado = app.addTask('   ');
    expect(resultado).to.be.null;
    expect(app.tasks.length).to.equal(0);
  });

  it('Regra: Deve criar a estrutura do objeto tarefa corretamente', () => {
    const tarefa = app.addTask('Estudar Automação');
    expect(tarefa).to.have.property('id');
    expect(tarefa.text).to.equal('Estudar Automação');
    expect(tarefa.isCompleted).to.be.false;
  });

  it('Regra: Deve inverter o status de conclusão na chamada do método toggleTask', () => {
    const tarefa = app.addTask('Testar método toggle');
    app.toggleTask(tarefa.id);
    expect(tarefa.isCompleted).to.be.true;
    
    app.toggleTask(tarefa.id);
    expect(tarefa.isCompleted).to.be.false;
  });

  it('Regra: Deve remover o item correto do array ao deletar', () => {
    const t1 = app.addTask('Manter item');
    const t2 = app.addTask('Remover item');

    app.deleteTask(t2.id);
    expect(app.tasks.length).to.equal(1);
    expect(app.tasks[0].id).to.equal(t1.id);
  });
});